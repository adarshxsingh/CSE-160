CSE 160 - Lab Activity 3

Adarsh Singh asing209@ucsc.edu 1930592

Group Members: Valentina Serrano

Files:
Camera.js
Context.js
Controls.js
index.js
styles.css

README.md — This file