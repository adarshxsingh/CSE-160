// Adarsh Singh
// asing209@ucsc.edu
// 1930592
// Lab Activity 3: UV Coordinates and Texturing

import { Matrix4, Vector3 } from "../lib/cuon-matrix-cse160";

export default class Cube {
  constructor() {
    this.position = new Vector3([0, 0, 0]);
    this.rotation = new Vector3([0, 0, 0]);
    this.scale = new Vector3([1, 1, 1]);
    this.modelMatrix = new Matrix4();

    this.textureSlots = [null, null];
    this.vertexBuffer = null;
    this.uvBuffer = null;

    this.initializeGeometry();
    this.mapUvs();
  }

  loadTexture(gl, imgPath, slot = 0) {
    const tex = gl.createTexture();
    const uSampler = gl.getUniformLocation(
      gl.program,
      slot === 0 ? "uTexture0" : "uTexture1"
    );

    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => {
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1);
      gl.activeTexture(slot === 0 ? gl.TEXTURE0 : gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texImage2D(
        gl.TEXTURE_2D,
        0,
        gl.RGBA,
        gl.RGBA,
        gl.UNSIGNED_BYTE,
        image
      );
      gl.uniform1i(uSampler, slot);
    };
    image.src = imgPath;

    this.textureSlots[slot] = tex;
  }

  initializeGeometry() {
    this.vertices = new Float32Array([
      // Front
      -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5, -0.5, 0.5, 0.5, 0.5,
      -0.5, 0.5, 0.5, 0.5, 0.5,
      // Left
      -0.5, 0.5, -0.5, -0.5, -0.5, -0.5, -0.5, -0.5, 0.5, -0.5, 0.5, -0.5, -0.5,
      -0.5, 0.5, -0.5, 0.5, 0.5,
      // Right
      0.5, 0.5, 0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, 0.5, 0.5, -0.5,
      -0.5, 0.5, 0.5, -0.5,
      // Top
      -0.5, 0.5, -0.5, -0.5, 0.5, 0.5, 0.5, 0.5, 0.5, -0.5, 0.5, -0.5, 0.5, 0.5,
      0.5, 0.5, 0.5, -0.5,
      // Back
      0.5, 0.5, -0.5, 0.5, -0.5, -0.5, -0.5, 0.5, -0.5, -0.5, 0.5, -0.5, 0.5,
      -0.5, -0.5, -0.5, -0.5, -0.5,
      // Bottom
      -0.5, -0.5, 0.5, -0.5, -0.5, -0.5, 0.5, -0.5, -0.5, -0.5, -0.5, 0.5, 0.5,
      -0.5, -0.5, 0.5, -0.5, 0.5
    ]);
  }

  mapUvs() {
    this.uvs = new Float32Array([
      // FRONT
      1, 0.25, 1, 0.5, 0.75, 0.5, 1, 0.25, 0.75, 0.5, 0.75, 0.25,
      // LEFT
      0.5, 0.25, 0.5, 0.5, 0.25, 0.5, 0.5, 0.25, 0.25, 0.5, 0.25, 0.25,
      // RIGHT
      0.5, 0.75, 0.5, 0.5, 0.75, 0.5, 0.5, 0.75, 0.75, 0.5, 0.75, 0.75,
      // TOP
      0.25, 0.25, 0.25, 0.5, 0, 0.5, 0.25, 0.25, 0, 0.5, 0, 0.25,
      // BACK
      0.5, 0.5, 0.5, 0.25, 0.75, 0.5, 0.75, 0.5, 0.5, 0.25, 0.75, 0.25,
      // BOTTOM
      0.75, 0.0, 0.5, 0, 0.5, 0.25, 0.75, 0, 0.5, 0.25, 0.75, 0.25
    ]);
  }

  updateModelMatrix() {
    const [x, y, z] = this.position.elements;
    const [rx, ry, rz] = this.rotation.elements;
    const [sx, sy, sz] = this.scale.elements;

    this.modelMatrix
      .setTranslate(x, y, z)
      .rotate(rx, 1, 0, 0)
      .rotate(ry, 0, 1, 0)
      .rotate(rz, 0, 0, 1)
      .scale(sx, sy, sz);
  }

  render(gl, camera) {
    this.updateModelMatrix();

    const aVertexPosition = gl.getAttribLocation(gl.program, "aPosition");
    const aUvCoord = gl.getAttribLocation(gl.program, "uv");

    gl.uniformMatrix4fv(
      gl.getUniformLocation(gl.program, "modelMatrix"),
      false,
      this.modelMatrix.elements
    );
    gl.uniformMatrix4fv(
      gl.getUniformLocation(gl.program, "viewMatrix"),
      false,
      camera.viewMatrix.elements
    );
    gl.uniformMatrix4fv(
      gl.getUniformLocation(gl.program, "projectionMatrix"),
      false,
      camera.projectionMatrix.elements
    );

    // Vertex Buffer
    if (!this.vertexBuffer) this.vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, this.vertices, gl.STATIC_DRAW);
    gl.vertexAttribPointer(aVertexPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(aVertexPosition);

    // UV Buffer
    if (!this.uvBuffer) this.uvBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.uvBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, this.uvs, gl.STATIC_DRAW);
    gl.vertexAttribPointer(aUvCoord, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(aUvCoord);

    gl.drawArrays(gl.TRIANGLES, 0, this.vertices.length / 3);
  }
}
