CSE 160 - Lab Activity 3

Adarsh Singh
asing209@ucsc.edu
1930592

Group Members: N/A

Files
index.js — Main entry point of the application. Sets up WebGL context, compiles shaders, loads textures, and starts the render loop.

Cube.js — Defines the Cube class that handles vertex setup, UV mapping, transformation matrix logic, and rendering. Supports multiple textures and blending.

README.md — This file