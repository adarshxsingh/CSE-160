// Adarsh Singh
// asing209@ucsc.edu
// 1930592
// Lab Activity 1: 2D drawing and transforms

import "./styles.css";
import { initShaders } from "../lib/cuon-utils";
import { Matrix4, Vector3 } from "../lib/cuon-matrix-cse160";

// HelloCube.js (c) 2012 matsuda
// Vertex shader program
// Vertex shader program
const VSHADER_SOURCE = `
  attribute vec2 aPosition;
  uniform mat4 uModelMatrix;
  void main() {
    gl_Position = uModelMatrix * vec4(aPosition, 0.0, 1.0);
  }
  `;

// Fragment shader program
const FSHADER_SOURCE = `
  #ifdef GL_ES
  precision mediump float;
  #endif
  void main() {
    gl_FragColor = vec4(1.0, 1.0, 1.0, 1.0);
  }
  `;

// Get canvas and WebGL context
var canvas = document.getElementById("webgl");

// Get the rendering context for WebGL
var gl = canvas.getContext("webgl");
if (!gl) {
  console.log("Failed to get the rendering context for WebGL");
}

// Initialize shaders
if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
  console.log("Failed to intialize shaders.");
}

// Set clear color
// gl.clearColor(0.0, 0.0, 0.0, 1.0);
gl.clearColor(0.2, 0.2, 0.2, 1.0);

gl.clear(gl.COLOR_BUFFER_BIT);

// === Define one right isosceles triangle ===
// The triangle points up and right from the origin
const vertices = new Float32Array([-0.5, -0.5, 0.5, -0.5, -0.5, 0.5]);

// Create and bind vertex buffer
const vertexBuffer = gl.createBuffer();
if (!vertexBuffer) {
  console.log("Failed to create the buffer object");
}

gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

// Link aPosition in vertex shader to vertex buffer
const aPosPtr = gl.getAttribLocation(gl.program, "aPosition");

if (aPosPtr < 0) {
  console.error("Could not find aPosition ptr");
}

gl.vertexAttribPointer(aPosPtr, 2, gl.FLOAT, false, 0, 0);
gl.enableVertexAttribArray(aPosPtr);

// === Apply different transforms to draw 4 different spaceships ===
const M = new Matrix4();

M.setTranslate(0.1, 0.2, 0);
M.scale(0.35, 0.35, 0.35);
M.rotate(-30, 0, 0, 1);
drawSpaceship(gl, M);

M.setTranslate(-0.63, -0.5, 0);
M.scale(0.25, 0.25, 0.25);
M.rotate(-30, 0, 0, 1);
drawSpaceship(gl, M);

M.setTranslate(0.63, 0.5, 0);
M.scale(0.15, 0.15, 0.15);
M.rotate(-30, 0, 0, 1);
drawSpaceship(gl, M);

M.setTranslate(0.4, -0.5, 0);
M.scale(0.275, 0.275, 0.275);
M.rotate(-30, 0, 0, 1);
drawSpaceship(gl, M);

M.setTranslate(0.8, -0.5, 0);
M.scale(0.124, 0.124, 0.124);
M.rotate(-30, 0, 0, 1);
drawSpaceship(gl, M);

M.setTranslate(-0.1, -0.5, 0);
M.scale(0.124, 0.124, 0.124);
M.rotate(-30, 0, 0, 1);
drawSpaceship(gl, M);

// === Function that draws a spaceship made of 9 triangles ===
function drawSpaceship(gl, matrix) {
  const uModelMatrixPtr = gl.getUniformLocation(gl.program, "uModelMatrix");
  const M1 = new Matrix4();

  // Center triangle (body)
  M1.set(matrix);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Triangle mirrored for body
  M1.set(matrix);
  M1.rotate(180, 0, 0, 1);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Top triangle
  M1.set(matrix);
  M1.translate(0, 0.51, 0);
  M1.rotate(225, 0, 0, 1);
  M1.scale(0.7, 0.7, 1);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Tail triangle
  M1.set(matrix);
  M1.translate(0, -0.76, 0);
  M1.scale(0.5, 0.5, 1);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Top tail mirror
  M1.set(matrix);
  M1.rotate(180, 0, 0, 1);
  M1.translate(0, 0.76, 0);
  M1.scale(0.5, 0.5, 1);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Right wing
  M1.set(matrix);
  M1.translate(-0.26, -0.86, 0);
  M1.rotate(315, 0, 0, 1);
  M1.scale(0.5, 0.5, 1);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Left wing
  M1.set(matrix);
  M1.translate(0.26, -0.86, 0);
  M1.rotate(135, 0, 0, 1);
  M1.scale(0.5, 0.5, 1);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Top left fin
  M1.set(matrix);
  M1.translate(0.61, -1.23, 0);
  M1.rotate(315, 0, 0, 1);
  M1.scale(0.5, 0.5, 1);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // Top right fin
  M1.set(matrix);
  M1.translate(-0.61, -1.23, 0);
  M1.rotate(135, 0, 0, 1);
  M1.scale(0.5, 0.5, 1);
  gl.uniformMatrix4fv(uModelMatrixPtr, false, M1.elements);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
}
