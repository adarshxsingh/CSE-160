CSE 160 – Lab Activity 1

Adarsh Singh  
asing209@ucsc.edu  
1930592  

Group Members: Valentina Serrano

## Files

- `index.js` — WebGL logic for rendering triangles and spaceships
- `styles.css` — Default styles for the canvas (minimal changes)
- `cuon-matrix-cse160.js` — Matrix and vector utility library used for transformations
- `README.md` — This file
