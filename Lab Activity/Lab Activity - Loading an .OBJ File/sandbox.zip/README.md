CSE 160 – Lab Activity 1

Adarsh Singh
asing209@ucsc.edu
1930592

Group Members: Valentina Serrano

Files
index.html
index.js
Model.js
Setup.js
shaders.js
README.md — This file